#ifndef _GATE_CONTROLLER_H_
#define _GATE_CONTROLLER_H_

class GateController
{
	public:
		GateController();
		GateController(int minWheels, int maxWheels);
		int GetGateStatus();
		void QueryCustomer();
		int IsLegit();
	private:
		int _gateStatus;
		int _numberOfWheels;
		int _minWheels;
		int _maxWheels;
		int _isLegit;
};

#endif
