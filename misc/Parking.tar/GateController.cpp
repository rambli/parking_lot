#include<iostream>
#include "GateController.h"
using namespace std;

GateController::GateController(){
	_gateStatus = 0;	// Closed by default
	_minWheels = 4;		// Car-only lot by default
	_maxWheels = 4;
	_isLegit = 0;		// Vehicle not allowed by default
}

GateController::GateController(int min, int max)
{
	_gateStatus = 0;
	_minWheels = min;
	_maxWheels = max;
	_isLegit = 0;
}

int GateController::IsLegit()
{
	return _isLegit;
}

int GateController::GetGateStatus()
{
	return _gateStatus;
}

void GateController::QueryCustomer()
{
	cout<<"Enter number of wheels:";
	cin>>_numberOfWheels;

	if( (_numberOfWheels < _minWheels) || (_numberOfWheels > _maxWheels) )
		// Lot does not support this type of vehicle, deny entry without querying lot
		_isLegit = 0;
	else
		_isLegit  = 1;	
}
