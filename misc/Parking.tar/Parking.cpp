#include<iostream>
#include "GateController.h"
#include "ParkingLot.h"
using namespace std;

int main()
{
	ParkingLot<class Vehicle> LotA;
	GateController gateController(4,10);

	// Build parking lot
	LotA.InsertType(std::pair<Vehicle, float>(Vehicle(4,15), 3000.));
	LotA.InsertType(std::pair<Vehicle, float>(Vehicle(6,15), 3000.));
	LotA.InsertType(std::pair<Vehicle, float>(Vehicle(8,15), 3000.));
	LotA.InsertType(std::pair<Vehicle, float>(Vehicle(10,15), 3000.));

	while(1)
	{
		// Loop to indicate lot is open
		gateController.QueryCustomer();

		// If vehicle is allowed, check if space available
		if(!gateController.IsLegit())
		{
			break;
		//	Vehicle v(gateController.getWheels));	
		}
	}

}
