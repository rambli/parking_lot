#ifndef _PARKING_LOT_H_
#define _PARKING_LOT_H_

template<class T>
class ParkingLot
{
	public:
		ParkingLot();
		void InsertType(T type);
		void InsertType(T type, int count);
		void Increment(T type);
		void Decrement(T type);
		int GetCount(T type);
	private:
		std::map<class T, std::int> _spotCount;
		int _maxCount;
}

template<class T>
ParkingLot<T>::ParkingLot()
{
	_spotCount.clear();
	_maxCount = 20;
}

template<class T>
void ParkingLot<T>::InsertType(T type)
{
	map<T,int>::iterator it;
	// check if type already exists befor inserting it
	it = _spotCount.find(type);
	
	if(it != _spotCount.end())
	{
		//_spotCount.insert[type] = 0;
		_spotCount.insert(std::pair<T, int>(type, _maxCount));
	}
}

template<class T>
void ParkingLot<T>::InsertType(T type, int count)
{
	if(count > _maxCount)
		count = _maxCount;

	//_spotCount.insert[type] = count;
	_spotCount.insert(std::pair<T, int>(type, count));
}

template<class T>
void ParkingLot<T>::Increment(T type)
{
	map<T,int>::iterator it;

	it = _spotCount.find(type);
	if( (it != _spotCount.end()) && ((*it).second < _maxCount) )
		(*it).second++;
}

template<class T>
void ParkingLot<T>::Decrement(T type)
{
        map<T,int>::iterator it;

        it = _spotCount.find(type);
        if( (it != _spotCount.end()) && ((*it).second != 0) )
                (*it).second--;         
}

template<class T>
int ParkingLot<T>::GetCount(T type)
{
	map<T,int>::iterator it;

	it = _spotCount.find(type);
	if(it != _spotCount.end())
		return ((*it).second);
}

#endif //_PARKING_LOT_H_
